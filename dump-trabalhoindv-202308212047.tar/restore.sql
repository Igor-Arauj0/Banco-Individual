--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.4
-- Dumped by pg_dump version 15.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trabalhoindv;
--
-- Name: trabalhoindv; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trabalhoindv WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE trabalhoindv OWNER TO postgres;

\connect trabalhoindv

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cartao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cartao (
    card_cd_id integer NOT NULL,
    card_tx_numero character varying(16) NOT NULL,
    fk_client_cd_id integer NOT NULL,
    card_tx_senha character varying(6) NOT NULL,
    card_dt_data_validade date NOT NULL
);


ALTER TABLE public.cartao OWNER TO postgres;

--
-- Name: cartao_card_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cartao_card_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cartao_card_cd_id_seq OWNER TO postgres;

--
-- Name: cartao_card_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cartao_card_cd_id_seq OWNED BY public.cartao.card_cd_id;


--
-- Name: cartao_fk_client_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cartao_fk_client_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cartao_fk_client_cd_id_seq OWNER TO postgres;

--
-- Name: cartao_fk_client_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cartao_fk_client_cd_id_seq OWNED BY public.cartao.fk_client_cd_id;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    client_cd_id integer NOT NULL,
    client_tx_nome character varying(50) NOT NULL,
    client_dt_data_nasc date NOT NULL,
    client_tx_cpf character varying(11) NOT NULL
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: clientes_client_cd_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clientes_client_cd_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_client_cd_id_seq OWNER TO postgres;

--
-- Name: clientes_client_cd_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clientes_client_cd_id_seq OWNED BY public.cliente.client_cd_id;


--
-- Name: cartao card_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao ALTER COLUMN card_cd_id SET DEFAULT nextval('public.cartao_card_cd_id_seq'::regclass);


--
-- Name: cartao fk_client_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao ALTER COLUMN fk_client_cd_id SET DEFAULT nextval('public.cartao_fk_client_cd_id_seq'::regclass);


--
-- Name: cliente client_cd_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN client_cd_id SET DEFAULT nextval('public.clientes_client_cd_id_seq'::regclass);


--
-- Data for Name: cartao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cartao (card_cd_id, card_tx_numero, fk_client_cd_id, card_tx_senha, card_dt_data_validade) FROM stdin;
\.
COPY public.cartao (card_cd_id, card_tx_numero, fk_client_cd_id, card_tx_senha, card_dt_data_validade) FROM '$$PATH$$/3333.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (client_cd_id, client_tx_nome, client_dt_data_nasc, client_tx_cpf) FROM stdin;
\.
COPY public.cliente (client_cd_id, client_tx_nome, client_dt_data_nasc, client_tx_cpf) FROM '$$PATH$$/3330.dat';

--
-- Name: cartao_card_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cartao_card_cd_id_seq', 3, true);


--
-- Name: cartao_fk_client_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cartao_fk_client_cd_id_seq', 1, false);


--
-- Name: clientes_client_cd_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clientes_client_cd_id_seq', 1, false);


--
-- Name: cartao cartao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT cartao_pkey PRIMARY KEY (card_cd_id);


--
-- Name: cliente clientes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT clientes_pkey PRIMARY KEY (client_cd_id);


--
-- Name: cartao cartao_fk_client_cd_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cartao
    ADD CONSTRAINT cartao_fk_client_cd_id_fkey FOREIGN KEY (fk_client_cd_id) REFERENCES public.cliente(client_cd_id);


--
-- PostgreSQL database dump complete
--

